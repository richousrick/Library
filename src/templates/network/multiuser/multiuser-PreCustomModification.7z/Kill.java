package templates.network.multiuser;

import java.io.Serializable;

/**
 * Sent after one end closes the connection
 * @author Richousrick
 */
public class Kill implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 645361740897729027L;

}
