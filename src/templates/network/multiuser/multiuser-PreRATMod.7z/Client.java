package templates.network.multiuser;

import java.io.IOException;
import java.net.Socket;
import java.net.UnknownHostException;

/**
 *@TODO Annotate Class
 *
 * @author Richousrick
 */
public class Client extends ConnectionHandler{

	
	/**
	 * Initiates the Client class
	 * @throws IOException 
	 * @throws UnknownHostException 
	 *
	 */
	public Client(String ip, int port) throws UnknownHostException, IOException {
		super(new Socket(ip, port));
		System.out.println("Connected="+socket.isConnected());
		try {
			handleConnection();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		disconnect(true);
	}
	
	public void disconnect(boolean waitForReply){
		try {
			Thread.sleep(1000);
			while(!toWrite.isEmpty()){
				toWrite.dequque();
			}
			Thread.sleep(1000);
			readThread.interrupt();
			readThread = null;
			write(new Kill());
			
			Thread.sleep(1000);
			writeThread.interrupt();
			writeThread = null;
		}catch(InterruptedException | NullPointerException e){
		}
		
		System.exit(0);
	}

	/* (non-Javadoc)
	 * @see templates.network.multiuser.ConnectionHandler#handleConnection()
	 */
	@Override 
	void handleConnection() throws InterruptedException{
	}
	
	public static void main(String[] args) throws UnknownHostException, IOException {
		Client c = new Client("localhost", 9999);
	}
	
}
