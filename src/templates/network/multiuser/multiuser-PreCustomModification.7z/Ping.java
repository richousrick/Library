package templates.network.multiuser;

import java.io.Serializable;

/**
 * Blank class used for handshaking between {@link Client} and {@link MultiUserServer}
 * @author Richousrick
 */
public class Ping implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 7259769442335021811L;
}
