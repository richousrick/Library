package templates.network.multiuser;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import datatypes.AtomicQueue;

/**
 *@TODO Annotate Class
 *
 * @author Richousrick
 */
public class MultiUserServer {

	static int MAX_ACTIVE_CONNECTIONS = 5;
	static int PORT = 9999;
	private static AtomicInteger currentConnections;
	private static MultiUserServer instance;
	
	private AtomicBoolean serverUp;
	private AtomicBoolean listening;
	private ServerSocket serverSocket;
	private Thread listenThread;
	private ArrayList<HandleClient> clients;
	
	/**
	 * Initiates the MultiUserServer class
	 * @throws IOException 
	 *
	 */
	public MultiUserServer() throws IOException {
		serverSocket = new ServerSocket(PORT);
		serverSocket.setReuseAddress(true);
		currentConnections = new AtomicInteger();
		serverUp = new AtomicBoolean(true);
		listening = new AtomicBoolean(false);
		instance = this;
		clients = new ArrayList<>();
		System.out.println("server initiated");
		listen();
	}
	
	/**
	 * Listens for incoming connections from clients
	 * @throws IOException
	 */
	public void listen() throws IOException{
		if(!listening.get()&&serverUp.get()){
			listening.set(true);
			listenThread = new Thread(new Runnable() {
				@Override
				public void run() {
					try{
						//serverUp checked twice so it will continue to check after server is full, but will stop once 
						while(serverUp.get()){
							while(currentConnections.get()<MAX_ACTIVE_CONNECTIONS&&serverUp.get()){
								if(serverSocket.isClosed()){
									serverSocket = new ServerSocket(PORT);
									serverSocket.setReuseAddress(true);
								}
								Socket sock = serverSocket.accept();
								HandleClient newClient = new HandleClient(sock);
								clients.add(newClient);
								newClient.start();
							}
							serverSocket.close();
							Thread.sleep(100);
						}
					}catch (IOException e){
						e.printStackTrace();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
			});
			listenThread.start();
			
		}
	}
	
	/**
	 * kills all current connections
	 */
	public void shutDown(){
		serverUp.set(false);
		listenThread.interrupt();
		try {
			if(!serverSocket.isClosed())
				serverSocket.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		while (clients.size()>0){
			clients.get(0).disconnect();
		}
		currentConnections.set(0);
	}
	
	/**
	 * will kill all processes associated with the client and remove all references
	 * @param client to disconnect from the server
	 */
	public void disconnectClient(HandleClient client){
		if(client.clientConnected.get()){
			client.disconnect();
		}else{
			try {
				client.getSocket().close();
				client.interrupt();
				clients.remove(client);
				currentConnections.decrementAndGet();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		
	}
	
	/**
	 * @return current instance of the server
	 */
	public static MultiUserServer getInstance(){
		return instance;
	}
	
	
	class HandleClient extends Thread{

		private Socket socket;
		private ObjectInputStream in;
		private ObjectOutputStream out;
		
		private AtomicQueue<Serializable> toWrite;
		private AtomicQueue<Object> recieved;
		
		private Thread readThread;
		private Thread writeThread;
		
		private AtomicBoolean clientConnected;
		
		/**
		 * Initiates the MultiUserServer.HandleClient class
		 *
		 */
		public HandleClient(Socket sock) {
			MultiUserServer.currentConnections.incrementAndGet();
			System.out.println("Curent Connections:"+currentConnections.get());
			this.socket = sock;
			try {
				out = new ObjectOutputStream(socket.getOutputStream());
				in = new ObjectInputStream(socket.getInputStream());
				toWrite = new AtomicQueue<>();
				recieved = new AtomicQueue<>();
				clientConnected = new AtomicBoolean(true);
				
				writeThread = new Thread(new Runnable() {
					
					@Override
					public void run() {
						try {
							long lastTime = System.currentTimeMillis();
							while(clientConnected.get()){
								if(toWrite.getSize()>0){
									out.writeObject(toWrite.pop());
									out.flush();
									lastTime = System.currentTimeMillis();
								}
								Thread.sleep(100);
								if(System.currentTimeMillis()-lastTime>30000){
									out.writeObject(new Ping());
									out.flush();
									lastTime=System.currentTimeMillis();
								}
							}
						}catch (InterruptedException e){
							
						}catch (IOException e){
							disconnect();
						}
					}
				});
				
				
				readThread = new Thread(new Runnable() {
					
					@Override
					public void run() {
						while(clientConnected.get()){
							Object o;
							try {
								o = in.readObject();
								if(o!=null && !o.getClass().equals(Ping.class)){
									recieved.push(o);
								}
							}catch (EOFException e){
							}catch (SocketException e){
								//TODO: ping to see what the problem was
								disconnect();
							} catch (ClassNotFoundException | IOException e) {
								e.printStackTrace();
							}
						}
					}
				});
				
				
				
			} catch (IOException e) {
				disconnect();
			}
			
		}
		
		/* (non-Javadoc)
		 * @see java.lang.Runnable#run()
		 */
		@Override
		public void run() {
			writeThread.start();
			readThread.start();
			try{
				handleClient();
			}catch (InterruptedException e){
				
			}
			disconnect();
		}
		
		/**
		 * Code that the server runs when connected to the client
		 */
		public void handleClient() throws InterruptedException{
			System.out.println(read());
			System.out.println(read());
			write("word1");
			write("word2");
			write("word3");
			Thread.sleep(1000);
		}
		
		/**
		 * waits for and returns the next object read from instream
		 * @return
		 */
		public Object read(){
			recieved.waitForData();
			return recieved.pop();
		}
		
		/**
		 * write the object to the outstream
		 * @param o
		 */
		public void write(Serializable o){
			toWrite.push(o);
		}
		
		/**
		 * Safely kill the connection between the client and server
		 */
		public void disconnect(){
			if(clientConnected.get()){
				clientConnected.set(false);
				kill();
				MultiUserServer.getInstance().disconnectClient(this);
			}
		}

		/**
		 * Forces the instance to stop 
		 */
		public void kill() {
			readThread.interrupt();
			writeThread.interrupt();
			readThread = null;
			writeThread = null;
		}
		
		/**
		 * 
		 * @return the {@link Socket} associated with this connection
		 */
		public Socket getSocket(){
			return socket;
		}
		
	}
	
	public static void main(String[] args) throws IOException {
		MultiUserServer server = new MultiUserServer();
	}
}
