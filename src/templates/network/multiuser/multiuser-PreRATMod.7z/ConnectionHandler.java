package templates.network.multiuser;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.net.SocketException;
import java.util.concurrent.atomic.AtomicBoolean;

import datatypes.AtomicQueue;

/**
 *@TODO Annotate Class
 *
 * @author Richousrick
 */
public abstract class ConnectionHandler extends Thread{

	protected ObjectInputStream in;
	protected ObjectOutputStream out;
	protected Socket socket;
	protected AtomicQueue<Serializable> toWrite;
	protected AtomicQueue<Object> recieved;
	protected AtomicBoolean clientConnected;
	protected Thread writeThread;
	protected Thread readThread;
	
	
	/**
	 * Initiates the ConnectionHandler class
	 * @param sock of the connection
	 */
	public ConnectionHandler(Socket sock) {
		this.socket = sock;
		try {
			out = new ObjectOutputStream(socket.getOutputStream());
			in = new ObjectInputStream(socket.getInputStream());
			toWrite = new AtomicQueue<>();
			recieved = new AtomicQueue<>();
			clientConnected = new AtomicBoolean(true);
			initWriteThread();
			initReadThread();
		} catch (IOException e) {
		}
	}
	
	/**
	 * Code to run when the connection has been made
	 */
	abstract void handleConnection() throws InterruptedException;		

	/**
	 * Initiates the write thread
	 */
	public void initWriteThread(){
		writeThread = new Thread(new Runnable() {
			
			@Override
			public void run() {
				try {
					long lastTime = System.currentTimeMillis();
					while(clientConnected.get()){
						if(toWrite.getSize()>0){
							Object o = toWrite.dequque();
							if(o instanceof Handshake){
								((Handshake) o).preSend(ConnectionHandler.this);
								((Handshake) o).postSend(ConnectionHandler.this);
							}else{
								out.writeObject(o);
								out.flush();
							}
							lastTime = System.currentTimeMillis();
						}
						Thread.sleep(100);
						if(System.currentTimeMillis()-lastTime>100000){
							out.writeObject(new Ping());
							out.flush();
							lastTime=System.currentTimeMillis();
						}
					}
				}catch (InterruptedException e){
					
				}catch (IOException e){
					disconnect(true);
				}
			}
		});
		writeThread.start();
	}
	
	/**
	 * Initiates the read thread
	 */
	public void initReadThread(){
		readThread = new Thread(new Runnable() {
			
			@Override
			public void run() {
				while(clientConnected.get()){
					Object o;
					try {
						o = in.readObject();
						if(o!=null){
							if(o instanceof Handshake){
								((Handshake) o).onRecieve(ConnectionHandler.this);
							}else{
								recieved.enqueue(o);
							}
						}
					}catch (EOFException e){
					}catch (SocketException e){
						disconnect(true);
					}catch (ClassNotFoundException | IOException e) {
						disconnect(true);
					}
				}
			}
		});
		readThread.start();
	}

	/**
	 * waits for and returns the next object read from instream
	 * @return
	 */
	public Object read(){
		recieved.waitForData();
		return recieved.dequque();
	}
	
	/**
	 * write the object to the outstream
	 * @param o
	 */
	public void write(Serializable o){
		toWrite.enqueue(o);
	}
	
	/**
	 * Code to run before the connection is closed
	 * @param b
	 */
	protected abstract void disconnect(boolean b);
}
