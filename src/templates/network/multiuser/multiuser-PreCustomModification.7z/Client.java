package templates.network.multiuser;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.concurrent.atomic.AtomicBoolean;

import datatypes.AtomicQueue;

/**
 *@TODO Annotate Class
 *
 * @author Richousrick
 */
public class Client {

	private ObjectInputStream in;
	private ObjectOutputStream out;
	private Socket socket;
	private AtomicQueue<Serializable> toWrite;
	private AtomicQueue<Object> recieved;
	private AtomicBoolean clientConnected;
	private Thread writeThread;
	private Thread readThread;
	
	/**
	 * Initiates the Client class
	 * @throws IOException 
	 * @throws UnknownHostException 
	 *
	 */
	public Client(String ip, int port) throws UnknownHostException, IOException {
		socket = new Socket(ip, port);
		System.out.println("Connected="+socket.isConnected());
		try {
			out = new ObjectOutputStream(socket.getOutputStream());
			in = new ObjectInputStream(socket.getInputStream());
			toWrite = new AtomicQueue<>();
			recieved = new AtomicQueue<>();
			clientConnected = new AtomicBoolean(true);
			
			writeThread = new Thread(new Runnable() {
				
				@Override
				public void run() {
					try {
						long lastTime = System.currentTimeMillis();
						while(clientConnected.get()){
							if(toWrite.getSize()>0){
								out.writeObject(toWrite.pop());
								out.flush();
								lastTime = System.currentTimeMillis();
							}
							Thread.sleep(100);
							if(System.currentTimeMillis()-lastTime>100000){
								out.writeObject(new Ping());
								out.flush();
								lastTime=System.currentTimeMillis();
							}
						}
					}catch (InterruptedException e){
						
					}catch (IOException e){
						disconnect(true);
					}
				}
			});
			writeThread.start();
			readThread = new Thread(new Runnable() {
				
				@Override
				public void run() {
					while(clientConnected.get()){
						Object o;
						try {
							o = in.readObject();
							if(o!=null && !o.getClass().equals(Ping.class)){
								if(o.getClass().equals(Kill.class)){
									disconnect(false);
								}else{
									recieved.push(o);
								}
							}
						}catch (EOFException e){
						}catch (SocketException e){
							//TODO: ping to see what the problem was
							disconnect(true);
						}catch (ClassNotFoundException | IOException e) {
							disconnect(true);
						}
					}
				}
			});
			readThread.start();
			
			handleClient();
			disconnect(true);
		} catch (IOException | InterruptedException e) {
		}
		
		disconnect(true);
	}
	
	/**
	 * code to run when connected to the server
	 */
	public void handleClient() throws InterruptedException{

	
	
	
	
	
	
	
	
	
	
	}
	
	/**
	 * waits for and returns the next object read from instream
	 * @return
	 */
	public Object read(){
		recieved.waitForData();
		return recieved.pop();
	}
	

	
	public void disconnect(boolean waitForReply){
		try {
			Thread.sleep(1000);
			while(!toWrite.isEmpty()){
				toWrite.pop();
			}
			Thread.sleep(1000);
			readThread.interrupt();
			readThread = null;
			write(new Kill());
			
			Thread.sleep(10000);
			writeThread.interrupt();
			writeThread = null;
		}catch(InterruptedException | NullPointerException e){
		}
		
		System.exit(0);
	}
	
	/**
	 * write the object to the outstream
	 * @param o
	 */
	public void write(Serializable o){
		toWrite.push(o);
	}
	
	public static void main(String[] args) throws UnknownHostException, IOException {
		Client client = new Client("localhost", 9999);
	}
}
